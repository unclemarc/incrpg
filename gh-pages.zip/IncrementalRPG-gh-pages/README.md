This project is not maintained.

IncrementalRPG
==============

Incremental Game with the goal of growing and growing as much as possible.

The original game can be played here: http://cdpn.io/AybpC

Project Page: http://samuelbeard.github.io/IncrementalRPG/game.html

==============

<h3>Our Goals</h3>
<ul>
  <li>Alter the style to better suit the theme.</li>
  <li>More types of accommodation.</li>
  <li>More buildings.</li>
  <li>More Upgrades</li>
  <li>Graphics and icons.</li>
</ul>


